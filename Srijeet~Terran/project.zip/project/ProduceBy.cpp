


#include <iostream>


#include <string>
#include <vector>
#include "Arbitary.cpp"
using namespace std;
#ifndef PRO_H_
#define PRO_H_
class ProduceBy:public Arbitary
{

};
#endif // PRO_H_




