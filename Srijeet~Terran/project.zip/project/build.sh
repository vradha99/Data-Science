#!/bin/bash

g++ -std=c++11 Terran.cpp ProduceBy.cpp Dependancy.cpp Building_Hash.cpp Unit_Hash.cpp Current_Buildings_Build_List.cpp Current_Buildings.cpp Current_Units.cpp Current_Units_Build_List.cpp Wait_List.cpp

