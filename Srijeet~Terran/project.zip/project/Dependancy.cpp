#include <iostream>


#include <string>
#include <vector>
#include "Arbitary.cpp"

using namespace std;
#ifndef DEP_H_
#define DEP_H_

class Dependancy:public Arbitary{

public:
   void print(){



	        for(int i=0; i!= presentL.size(); ++i){

	      //	 cout<<currentList[i]<<endl;
	        }


	    }

};

#endif





