from .alexnet import create as alexnet
from .resnet import create as resnet
