import tensorflow as tf


def create(x, num_outputs, dropout_rate = 0.5):
    '''
        args:
            x               network input
            num_outputs     number of logits
            dropout         dropout rate during training
    '''
    
    is_training = tf.get_variable('is_training', (), dtype = tf.bool, trainable = False)

    # TODO

    pass

